== How to install Aristois ==

1. Make sure the Minecraft launcher and Minecraft is closed
2. Copy the folder in this zip file to .minecraft/versions/
3. Start the Minecraft launcher and click the three stripes in the top right corner
4. Press "launch options" and then click "Add new"
5. Select release and then in the dropdown select "release <mcversion>-Aristois" and hit save
6. Head to news and click the arrow to the right of the start button and select Aristois
7. Start Aristois

== How to find .minecraft/versions/ ==

1. Press Win+R
2. Type %appdata% and press enter
3. Go into the .minecraft folder
4. Go into the versions folder
